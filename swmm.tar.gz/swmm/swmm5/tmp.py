from swmm5.swmm5tools import SWMM5Simulation
st=SWMM5Simulation("swmm5/examples/simple/swmm5Example.inp")